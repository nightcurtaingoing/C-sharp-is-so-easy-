﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Service
{
    public partial class Form1 : Form
    {
        IPAddress ip;
        TcpListener listener;
        TcpClient tcpClient;


        public Form1()
        {
            InitializeComponent();
            Control.CheckForIllegalCrossThreadCalls = false;
        }
        
        private void buttonStart_Click(object sender, EventArgs e)
        {
            ip = IPAddress.Parse(this.textBoxIp.Text);//创建IP
            listener = new TcpListener(ip, Convert.ToInt32(this.textBoxPort.Text));
            listener.Start();
            this.textBoxInfo.Text = "服务器启动-" + DateTime.Now.ToShortTimeString() + "\r\n" + this.textBoxInfo.Text;
            this.backgroundWorker1.RunWorkerAsync();
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            tcpClient = listener.AcceptTcpClient();//中断 等待 
            this.textBoxInfo.Text = "连接成功-" + DateTime.Now.ToShortTimeString() + "\r\n" + this.textBoxInfo.Text;

            NetworkStream stream = tcpClient.GetStream();
            byte[] byteArray = new byte[1024];
            while (true)
            {
                int length = stream.Read(byteArray, 0, 1024); //读取流里面的字节, length剔除最后零
                string receiveMessage = Encoding.Unicode.GetString(byteArray, 0, length);
                this.textBoxInfo.Text = "接收到：-" + receiveMessage + "-" + DateTime.Now.ToShortTimeString() + "\r\n" + this.textBoxInfo.Text; 
            }

        }

        private void buttonSend_Click(object sender, EventArgs e)
        {
            string message = this.textBoxInput.Text;
            this.textBoxInfo.Text = "发送" + message + "-" + DateTime.Now.ToShortTimeString() + "\r\n" + this.textBoxInfo.Text;
            NetworkStream stream = tcpClient.GetStream();
            byte[] byteArray = Encoding.Unicode.GetBytes(message);
            stream.Write(byteArray, 0, byteArray.Length);  //发送字节数组
        }
    }
}
